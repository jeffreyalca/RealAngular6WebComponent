import { ToggleDirective } from './toggle/toggle.directive';

export const directives: any[] = [
  ToggleDirective,
];

export * from './toggle/toggle.directive';

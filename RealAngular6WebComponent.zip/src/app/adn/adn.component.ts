import {Component, OnInit, ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'adn-element',
  templateUrl: './adn.component.html',
  styleUrls: ['./adn.component.scss'],
  // encapsulation: ViewEncapsulation.Emulated,
})
export class AdnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

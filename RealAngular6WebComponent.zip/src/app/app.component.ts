import { Component } from '@angular/core';

@Component({
   selector: 'app-first-component',
   template: `
      <!--The content below is only a placeholder and can be replaced.-->
      <adn-element></adn-element>  
   `,
   styles: []
})
export class AppComponent {
   title = 'First Component';
}



